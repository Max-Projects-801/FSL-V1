"""
Main renderer - runs the whole system
"""
import os
import sys
from engine import CSVStylerEngine
from parser import JoanParser
from exporters import HTMLExporter, ExcelExporter
import glob

def find_csv_files():
    """Find CSV files in current directory"""
    csv_files = glob.glob("*.csv")
    
    if not csv_files:
        print("❌ No CSV files found in current directory!")
        print("Please add a CSV file first.")
        return []
    
    return csv_files

def find_style_files():
    """Find Joan-style files"""
    style_files = []
    for ext in ['.joan', '.style', '.css']:
        style_files.extend(glob.glob(f"*{ext}"))
    return style_files

def main():
    """Main render function"""
    print("=" * 50)
    print("🎨 CSV STYLER ENGINE v1.0")
    print("=" * 50)
    
    # Find CSV files
    csv_files = find_csv_files()
    if not csv_files:
        return
    
    print(f"\n📁 Found {len(csv_files)} CSV file(s):")
    for i, file in enumerate(csv_files, 1):
        print(f"  {i}. {file}")
    
    # Find style files
    style_files = find_style_files()
    if not style_files:
        print("\n⚠️  No style files found (.joan, .style, .css)")
        print("Creating default style...")
        default_style = """
/start.style {
    rows:all {
        font-family: "Arial";
        font-size: 12px;
    }
    
    rows:nth-child(even) {
        background-color: #f5f5f5;
    }
    
    column[name="price"] {
        color: green;
        font-weight: bold;
    }
}
"""
        with open("default.joan", "w") as f:
            f.write(default_style)
        print("✅ Created default.joan file")
        style_files = ["default.joan"]
    
    print(f"\n🎨 Found {len(style_files)} style file(s):")
    for i, file in enumerate(style_files, 1):
        print(f"  {i}. {file}")
    
    # Ask user which files to process
    try:
        csv_choice = input("\n📝 Enter CSV file number (or press Enter for first): ").strip()
        csv_index = int(csv_choice) - 1 if csv_choice else 0
        
        style_choice = input("🎨 Enter style file number (or press Enter for first): ").strip()
        style_index = int(style_choice) - 1 if style_choice else 0
        
        csv_file = csv_files[csv_index]
        style_file = style_files[style_index]
        
    except (ValueError, IndexError):
        print("❌ Invalid selection. Using first files.")
        csv_file = csv_files[0]
        style_file = style_files[0]
    
    print(f"\n⚙️  Processing: {csv_file} with {style_file}")
    
    # Initialize engine
    engine = CSVStylerEngine()
    
    # Load CSV
    print(f"📥 Loading {csv_file}...")
    engine.load_csv(csv_file)
    
    # Parse styles
    print(f"🎨 Parsing {style_file}...")
    parser = JoanParser()
    styles = parser.parse_file(style_file)
    
    # Apply styles
    print("✨ Applying styles...")
    engine.apply_styles(styles)
    
    # Ask for export format
    print("\n📤 Export options:")
    print("  1. HTML (colored table)")
    print("  2. Excel (.xlsx)")
    print("  3. Terminal preview")
    print("  4. All formats")
    
    choice = input("Choose option (1-4, default: 3): ").strip()
    
    # Export based on choice
    base_name = os.path.splitext(csv_file)[0]
    
    if choice == "1" or choice == "4":
        html_exporter = HTMLExporter()
        html_output = f"{base_name}_styled.html"
        html_exporter.export(engine.get_styled_dataframe(), html_output)
        print(f"✅ HTML exported to: {html_output}")
    
    if choice == "2" or choice == "4":
        excel_exporter = ExcelExporter()
        excel_output = f"{base_name}_styled.xlsx"
        excel_exporter.export(engine.get_styled_dataframe(), excel_output)
        print(f"✅ Excel exported to: {excel_output}")
    
    if choice == "3" or choice == "" or choice == "4":
        # Terminal preview
        print("\n" + "=" * 60)
        print("📊 TERMINAL PREVIEW")
        print("=" * 60)
        
        styled_df = engine.get_styled_dataframe()
        
        # Show first few rows
        print("\nFirst 5 rows:")
        print("-" * 40)
        
        for i in range(min(5, len(styled_df))):
            row = styled_df.iloc[i]
            
            # Check for styling
            row_str = ""
            for col in styled_df.columns:
                if not col.startswith("__"):  # Skip internal columns
                    value = row[col]
                    
                    # Check for bold
                    bold = styled_df.get(f"__{col}_bold", False)
                    if bold and i < len(bold) and bold[i]:
                        value = f"\033[1m{value}\033[0m"
                    
                    row_str += f"{value}\t"
            
            # Check for row background
            bg = styled_df.get("__row_bg", "")
            if i < len(bg) and bg[i]:
                # Add ANSI background color
                pass
            
            print(row_str)
        
        print(f"\nTotal rows: {len(styled_df)}")
        print(f"Total columns: {len([c for c in styled_df.columns if not c.startswith('__')])}")
    
    print("\n🎉 Done! Check your styled files in the current directory.")

if __name__ == "__main__":
    main()
