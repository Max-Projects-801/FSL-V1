"""
Utility functions
"""
import os
import sys

def print_colored(text: str, color: str = "green"):
    """Print colored text to terminal"""
    colors = {
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "purple": "\033[95m",
        "cyan": "\033[96m",
        "white": "\033[97m",
        "bold": "\033[1m",
        "underline": "\033[4m",
    }
    
    end = "\033[0m"
    color_code = colors.get(color, "")
    
    print(f"{color_code}{text}{end}")

def get_file_size(filepath: str) -> str:
    """Get human readable file size"""
    size = os.path.getsize(filepath)
    
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024.0:
            return f"{size:.1f}{unit}"
        size /= 1024.0
    
    return f"{size:.1f}TB"

def validate_csv(filepath: str) -> bool:
    """Validate CSV file"""
    if not os.path.exists(filepath):
        return False
    
    if not filepath.endswith('.csv'):
        return False
    
    try:
        with open(filepath, 'r') as f:
            lines = f.readlines()
            return len(lines) > 0
    except:
        return False

def create_sample_files():
    """Create sample files for testing"""
    
    # Sample CSV
    sample_csv = """name,price,quantity,category,date
Apple,1.99,100,Fruits,2024-01-15
Banana,0.99,50,Fruits,2024-01-16
Laptop,999.99,10,Electronics,2024-01-14
Mouse,25.50,45,Electronics,2024-01-13
Book,15.99,200,Books,2024-01-12"""
    
    with open("sample.csv", "w") as f:
        f.write(sample_csv)
    
    # Sample style file
    sample_style = """
import required "styler" "colorizer"

required {
    *basic-styles
    *color-palette
}

filename("sample.csv")

load.filename {
    /start.style {
        rows:all {
            font-family: "Arial";
            font-size: 12px;
        }
        
        rows:nth-child(even) {
            background-color: #f5f5f5;
        }
        
        column[name="price"] {
            color: green;
            font-weight: bold;
            format: currency;
        }
        
        column[name="quantity"] {
            text-align: center;
        }
        
        rows:where(column["quantity"] < 60) {
            background-color: #fff3cd;
            border-left: 3px solid orange;
        }
    }
}
"""
    
    with open("sample.joan", "w") as f:
        f.write(sample_style)
    
    print("✅ Created sample.csv and sample.joan files")
