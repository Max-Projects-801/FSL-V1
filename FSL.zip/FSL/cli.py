"""
Simple CLI interface
"""
import argparse
from render import main as render_main

def run_cli():
    """Run the CLI interface"""
    parser = argparse.ArgumentParser(
        description="🎨 CSV Styler - Style your CSV files with Joan syntax",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli.py                    # Interactive mode
  python cli.py --csv data.csv --style mystyle.joan
  python cli.py --list            # List available files
  python cli.py --preview         # Preview without export
        """
    )
    
    parser.add_argument("--csv", help="CSV file to style")
    parser.add_argument("--style", help="Style file (.joan, .style, .css)")
    parser.add_argument("--output", help="Output file (HTML/Excel)")
    parser.add_argument("--list", action="store_true", help="List available files")
    parser.add_argument("--preview", action="store_true", help="Preview in terminal only")
    parser.add_argument("--version", action="store_true", help="Show version")
    
    args = parser.parse_args()
    
    if args.version:
        print("CSV Styler v1.0")
        return
    
    if args.list:
        from render import find_csv_files, find_style_files
        csv_files = find_csv_files()
        style_files = find_style_files()
        
        print("📁 CSV Files:")
        for f in csv_files:
            print(f"  - {f}")
        
        print("\n🎨 Style Files:")
        for f in style_files:
            print(f"  - {f}")
        return
    
    # If no arguments, run interactive mode
    if not any([args.csv, args.style, args.output, args.preview]):
        render_main()
    else:
        print("🚀 Direct mode coming soon!")
        print("For now, use: python render.py")

if __name__ == "__main__":
    run_cli()
