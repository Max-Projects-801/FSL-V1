"""
Core CSV styling engine
"""
import pandas as pd
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

@dataclass
class StyleRule:
    selector: str
    properties: Dict[str, str]

class CSVStylerEngine:
    """Main engine that applies styles to CSV files"""
    
    def __init__(self):
        self.df = None
        self.styles = []
        self.styled_df = None
        
    def load_csv(self, filepath: str):
        """Load CSV file"""
        self.df = pd.read_csv(filepath)
        return self
    
    def apply_styles(self, styles: List[StyleRule]):
        """Apply styles to the loaded CSV"""
        self.styles = styles
        self.styled_df = self.df.copy()
        
        # Apply styling logic
        for rule in styles:
            self._apply_rule(rule)
            
        return self
    
    def _apply_rule(self, rule: StyleRule):
        """Apply a single style rule"""
        # Basic selector matching
        if rule.selector.startswith("column[name="):
            # Extract column name
            col_name = rule.selector.split('"')[1]
            if col_name in self.styled_df.columns:
                self._style_column(col_name, rule.properties)
        
        elif rule.selector == "rows:all":
            self._style_all_rows(rule.properties)
            
        elif rule.selector == "rows:nth-child(even)":
            self._style_even_rows(rule.properties)
            
        elif rule.selector == "rows:nth-child(odd)":
            self._style_odd_rows(rule.properties)
    
    def _style_column(self, column: str, props: Dict[str, str]):
        """Style a specific column"""
        if "color" in props:
            # Add color tag for later rendering
            self.styled_df[f"__{column}_color"] = props["color"]
        
        if "bold" in props and props["bold"] == "true":
            self.styled_df[f"__{column}_bold"] = True
    
    def _style_all_rows(self, props: Dict[str, str]):
        """Style all rows"""
        if "background-color" in props:
            self.styled_df["__row_bg"] = props["background-color"]
    
    def _style_even_rows(self, props: Dict[str, str]):
        """Style even rows"""
        for i in range(len(self.styled_df)):
            if i % 2 == 0:  # 0-indexed, so even indices
                self.styled_df.at[i, "__row_bg_even"] = props.get("background-color", "")
    
    def _style_odd_rows(self, props: Dict[str, str]):
        """Style odd rows"""
        for i in range(len(self.styled_df)):
            if i % 2 != 0:
                self.styled_df.at[i, "__row_bg_odd"] = props.get("background-color", "")
    
    def get_styled_dataframe(self):
        """Get the styled dataframe"""
        return self.styled_df
    
    def get_original_dataframe(self):
        """Get original dataframe"""
        return self.df
