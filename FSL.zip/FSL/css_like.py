"""
CSS-like styling processor
"""
import re

class CSSProcessor:
    """Process CSS-like selectors"""
    
    @staticmethod
    def parse_selector(selector: str):
        """Parse CSS selector into components"""
        
        # Column selector: column[name="price"]
        col_match = re.match(r'column\[name="([^"]+)"\]', selector)
        if col_match:
            return {"type": "column", "name": col_match.group(1)}
        
        # Row selectors
        if selector == "rows:all":
            return {"type": "rows", "selector": "all"}
        
        if selector == "rows:nth-child(even)":
            return {"type": "rows", "selector": "even"}
        
        if selector == "rows:nth-child(odd)":
            return {"type": "rows", "selector": "odd"}
        
        # Conditional selector: rows:where(column["status"] == "urgent")
        where_match = re.match(r'rows:where\(([^)]+)\)', selector)
        if where_match:
            condition = where_match.group(1)
            return {"type": "rows", "selector": "where", "condition": condition}
        
        return {"type": "unknown", "selector": selector}
    
    @staticmethod
    def parse_properties(props: Dict[str, str]) -> Dict[str, Any]:
        """Parse CSS properties"""
        parsed = {}
        
        for key, value in props.items():
            # Color properties
            if key in ["color", "background-color"]:
                parsed[key] = CSSProcessor.parse_color(value)
            
            # Font properties
            elif key == "font-weight":
                parsed[key] = True if value == "bold" else value
            
            elif key == "font-size":
                parsed[key] = value
            
            elif key == "font-family":
                parsed[key] = value.strip('"')
            
            # Text properties
            elif key == "text-align":
                parsed[key] = value
            
            # Format properties
            elif key == "format":
                parsed[key] = value
            
            # Border properties
            elif key.startswith("border"):
                parsed[key] = value
        
        return parsed
    
    @staticmethod
    def parse_color(color: str) -> str:
        """Parse color value"""
        # Hex color
        if re.match(r'^#[0-9A-Fa-f]{3,6}$', color):
            return color
        
        # Named colors
        color_map = {
            "red": "#ff0000",
            "green": "#00ff00",
            "blue": "#0000ff",
            "yellow": "#ffff00",
            "orange": "#ffa500",
            "purple": "#800080",
            "black": "#000000",
            "white": "#ffffff",
            "gray": "#808080",
            "lightgray": "#d3d3d3",
        }
        
        return color_map.get(color.lower(), color)
