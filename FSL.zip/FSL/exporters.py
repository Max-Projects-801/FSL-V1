"""
Export styled data to different formats
"""
import pandas as pd
from typing import Dict, Any

class HTMLExporter:
    """Export to HTML with styling"""
    
    def export(self, styled_df, output_path: str):
        """Export to HTML file"""
        
        # Remove internal styling columns
        display_df = styled_df.copy()
        internal_cols = [c for c in display_df.columns if c.startswith("__")]
        for col in internal_cols:
            if col in display_df.columns:
                display_df = display_df.drop(columns=[col])
        
        # Create HTML with basic styling
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                table {
                    border-collapse: collapse;
                    width: 100%;
                    font-family: Arial, sans-serif;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #4CAF50;
                    color: white;
                }
                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                tr:hover {
                    background-color: #ddd;
                }
                .bold {
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
            <h2>Styled CSV Data</h2>
            <table>
        """
        
        # Add headers
        html += "<tr>"
        for col in display_df.columns:
            html += f"<th>{col}</th>"
        html += "</tr>\n"
        
        # Add rows
        for idx, row in display_df.iterrows():
            html += "<tr>"
            
            for col in display_df.columns:
                value = str(row[col])
                
                # Check for bold styling
                bold_col = f"__{col}_bold"
                is_bold = (bold_col in styled_df.columns and 
                          idx < len(styled_df[bold_col]) and 
                          styled_df.at[idx, bold_col])
                
                # Check for color
                color_col = f"__{col}_color"
                color = ""
                if color_col in styled_df.columns and idx < len(styled_df[color_col]):
                    color = styled_df.at[idx, color_col]
                
                # Build cell
                style = ""
                if color:
                    style += f"color: {color};"
                if is_bold:
                    style += "font-weight: bold;"
                
                if style:
                    html += f'<td style="{style}">{value}</td>'
                else:
                    html += f'<td>{value}</td>'
            
            html += "</tr>\n"
        
        html += """
            </table>
        </body>
        </html>
        """
        
        with open(output_path, 'w') as f:
            f.write(html)

class ExcelExporter:
    """Export to Excel with styling"""
    
    def export(self, styled_df, output_path: str):
        """Export to Excel file"""
        # For simplicity, just save as CSV for now
        # In real implementation, use openpyxl for Excel formatting
        display_df = styled_df.copy()
        internal_cols = [c for c in display_df.columns if c.startswith("__")]
        for col in internal_cols:
            if col in display_df.columns:
                display_df = display_df.drop(columns=[col])
        
        display_df.to_csv(output_path.replace('.xlsx', '_styled.csv'), index=False)
