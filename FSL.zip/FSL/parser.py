"""
Parse Joan-style syntax into style rules
"""
import re
from engine import StyleRule

class JoanParser:
    """Parse Joan-style syntax"""
    
    def __init__(self):
        self.rules = []
        
    def parse(self, content: str) -> List[StyleRule]:
        """Parse Joan-style content"""
        lines = content.strip().split('\n')
        current_selector = None
        current_props = {}
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # Skip empty lines and comments
            if not line or line.startswith("//"):
                i += 1
                continue
            
            # Start of style block
            if line == "/start.style {":
                i += 1
                continue
            
            # End of style block
            if line == "}":
                if current_selector:
                    self.rules.append(StyleRule(current_selector, current_props.copy()))
                    current_selector = None
                    current_props = {}
                i += 1
                continue
            
            # Selector line (ends with {)
            if line.endswith("{"):
                # Save previous rule if exists
                if current_selector:
                    self.rules.append(StyleRule(current_selector, current_props.copy()))
                    current_props = {}
                
                current_selector = line[:-1].strip()
                i += 1
                continue
            
            # Property line (key: value)
            if ":" in line and not line.startswith("}"):
                key_value = line.rstrip(';').split(":", 1)
                if len(key_value) == 2:
                    key = key_value[0].strip()
                    value = key_value[1].strip()
                    current_props[key] = value
            
            i += 1
        
        return self.rules
    
    def parse_file(self, filepath: str) -> List[StyleRule]:
        """Parse a Joan-style file"""
        with open(filepath, 'r') as f:
            content = f.read()
        return self.parse(content)
